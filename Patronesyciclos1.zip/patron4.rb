n = ARGV[0].to_i

(n / 3).times do |i|
    print 123
end

puts